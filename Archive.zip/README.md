# Spodial Chat

AI-powered chat interface for paint-by-numbers product recommendations.

## Live Demo
Visit: https://zhernovoy.github.io/Spodial_zvetnoe/

## Features
- AI-powered product recommendations
- Real-time chat interface
- Product catalog integration
